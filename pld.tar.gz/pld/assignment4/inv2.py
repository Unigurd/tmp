# An environment is a dictionary
# where every variable is 0 until changed
# and allowing local bindings
class Environment:
    def __init__(self):
        self.dict = {}

    # String representation is that of the dictionary's
    # For debugging
    def __str__(self):
        return str(self.dict)

    # Iterate through an environment like a dictionary
    def __iter__(self):
        return self.dict.__iter__()

    # Get value if key is found,
    # otherwise return 0
    def __getitem__(self, key):
        if key in self.dict:
            return (self.dict[key])[-1]
        else: return 0

    # Set item
    def __setitem__(self, key, val):
        # Change the value if key is found
        if key in self.dict:
            self.dict[key][-1] = val
        # Add key and value if key is not found.
        # value is a list to remember old bindings
        # when binding locally
        else:
            self.dict[key] = [val]

        self.clean(key)

    # Enter a local binding
    def local(self, key):
        # If nothing is at [key] in dict,
        # this will add [0]
        # for easier detection of when it is
        # valid to delete the entire entry
        # in the dictionary
        if not(key in self.dict):
            self.dict[key] = [0]
        self.dict[key].append(0)

    # Exit a local binding
    def lacol(self, key):
        old_val = self.dict[key].pop()
        if old_val != 0:
            raise Exception(key + " is not 0 on end of local scope")
        self.clean(key)

    # swap two variables
    def swap(self, x, y):
        (self[x],self[y]) = (self[y],self[x])

    # Read a variable from stdin
    # Check that the variable was 0 before
    def read(self,x):
        if self[x] != 0:
            raise exception (str(x) + " is not 0 on read")
        self[x] = int(input(x + ": "))

    # write a variable to stdout,
    # and sets it to 0 afterwards
    def write(self,x):
        # write n
        print(x + ": " + str(self[x]))
        self[x] = 0


    # Removes an entry from the dictionary
    # if it is 0 and not bound locally
    def clean(self, key):
        # not_in_dict = not(key in self.dict)
        empty_list = len(self.dict[key]) == 0
        only_zero = len(self.dict[key]) == 1 and self.dict[key] == [0]
        if empty_list or only_zero:
            del self.dict[key]

# Runs a program with all variables = 0 at start
# and checks that they're still 0 at the end
def run_program(program):
    env = Environment()
    program(env)
    for n in env:
        if env[n] != 0:
            raise Exception ("Variable " + n + " not 0 on termination")


# The gcd program
def gcd(env):
    # read m;
    env.read('m')

    # read n;
    env.read('n')

    # call rec;
    rec(env)

    # write m;
    env.write('m')

    # write n;
    env.write('n')

    # g <-> result;
    env.swap('g',"result")

    # write g;
    env.write('g')

# procedure rec
def rec(env):
    # local g in
    env.local('g')

    # g += m mod n;
    env['g'] = env['g'] + (env['m'] % env['n'])

    # m <-> n;
    env.swap('m','n')

    # g <-> n;
    env.swap('g','n')

    # if n=0 || g=0
    entry_cond = env['n']==0 or env['g']==0

    # then
    if entry_cond:
        # result += m
        env["result"] = env['m']

    # else
    else:
        # call rec
        rec(env)

    # fi n=0 || g=0
    exit_cond = env['n']==0 or env['g']==0
    if entry_cond != exit_cond:
        raise Exception("entry and exit condition of if-statement not equal")

    # g <-> n;
    env.swap('g','n')

    # m <-> n;
    env.swap('m','n')

    # g -= m mod n
    env['g'] -= (env['m'] % env['n'])

    # lacol
    env.lacol('g')

# end
