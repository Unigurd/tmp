% My values
type(intList, list(int)).
type(boolList,list(bool)).
type(prodList,list(int-int)).

% Assignment dictionaries

type(myVal, myType(A)).

type(myDict(X),myClass(myType(A))) :-
    type(X,
  adding: prol1.pl (deflated 60%)
  adding: prol2.pl (deflated 59%)
  adding: prol3.pl (deflated 61%)

type(reqInt(X), eq(int)) :-
    type(X,eq(bool)).

type(reqBool(X), eq(bool)) :-
    type(X,eq(int)).

type(eqInt,eq(int)).
type(eqBool,eq(bool)).

type(intVal1,int).
type(intVal2,int).



% A sorting function
type(qsortP(D, L), list(A)) :-
    type(D,ord(A)),
    type(L,list(A)).

utype(V,T) :- type(V,T), !.

duplicates(D1, D2, T) :-
  type(D2, T),
  type(D1, T),
  D1 \= D2.

uDuplicates(D1, D2, T) :-
  uType(D2, T),
  uType(D1, T),
  D1 \= D2.
