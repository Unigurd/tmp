% My values
type(intList, list(int)) :- !.
type(boolList,list(bool)) :- !.
type(prodList,list(int-int)) :- !.


% Assignment dictionaries

% eqInt has type Eq Int.
type(eqInt,  eq(int)) :-
    !.

% ordInt has type Ord Int.
type(ordInt, ord(int)) :-
    !.

% ordBool(X) has type Ord Bool if X has type Ord Int.
type(ordBool(X), ord(bool)) :-
    type(X, ord(int)),
    !.

% ordpair(X, Y) has type Ord (Prod A B) if X has type Ord A and Y has type Ord B.
type(ordPair(X,Y), ord(A-B)) :-
    type(X, ord(A)),
    type(Y, ord(B)),
    !.

% optimizedOrd has type Ord (Prod Int Int).
type(optimizedOrd, ord(int-int)) :-
    !.

% qsort’(D, L) has type List A if D has type Ord A and L has type List A.
type(qsortP(D, L), list(A)) :-
    type(D,ord(A)),
    type(L,list(A)),
    !.

wraptype(V,T) :- type(V,T), !.

ambiguous(V1, V2, T) :-
  V1 \= V2,
  type(V2, T),
  type(V1, T).
