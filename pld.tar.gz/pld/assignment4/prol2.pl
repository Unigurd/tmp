[prol1].

% X has type B if X has type A and A is a subtype of B.
type(X,B) :-
    subtype(A,B),
    type(X,A).

%  Subtyping
subtype(int,real).

% Bool is a subtype of Int.
subtype(bool,int).

% List A is a subtype of List B if A is a subtype of B.
subtype(list(A),list(B)) :-
    subtype(A,B).

% If A is a subtype of B and B is a subtype of C, A is a subtype of C.
subtype(A,C) :-
    subtype(B,C),
    subtype(A,B).
