def lookup(env,var):
    if not(isinstance(var, str)):
        return var

    try: return env[var]
    except KeyError:
        env[var] = 0
        return 0

class Invertible:
    def call(self):
        raise Exception('call not implemented')

    def invert(self):
        raise Exception('invert not implemented')

    def uncall(self, *args):
        self.invert().call(*args)

class PlusAssign(Invertible):
    def __init__(self,env,var,exp):
        self.env = env
        self.var = var
        self.exp = exp

    def call(self):
        oldVal = lookup(self.env,self.var)
        self.env[self.var] = oldVal + self.exp.assign(self.var)

    def invert(self):
        return MinusAssign(self.env,self.var,self.exp)

class MinusAssign(Invertible):
    def __init__(self,env,var,exp):
        self.env = env
        self.var = var
        self.exp = exp

    # Does not check that var is not used in the expression
    def call(self):
        oldVal = lookup(self.env,self.var)
        self.env[self.var] = oldVal - self.exp.assign(self.var)

    def invert(self):
        return PlusAssign(self.env,self.var,self.exp)

class Swap(Invertible):
    def __init__(self,env,var1,var2):
        self.env = env
        self.var1 = var1
        self.var2 = var2

    def call(self):
        tmp = lookup(self.env,self.var1)
        self.env[self.var1] = lookup(self.env,self.var2)
        self.env[self.var2] = tmp

    def invert(self):
        return self

class Read(Invertible):
    def __init__(self, env, var):
        self.env = env
        self.var = var

    def call(self):
        val = lookup(self.env,self.var)
        if val != 0:
            raise Exception ('Self.Variable ' + self.var + ' should be 0 when read, but is ' + str(val))
        else:
            self.env[self.var] = int(input())

    def invert(self):
        return Write(self.env,self.var)

class Write(Invertible):
    def __init__(self, env, var):
        self.env = env
        self.var = var

    def call(self):
        print(lookup(self.env,self.var))
        self.env[self.var] = 0

    def invert(self):
        return Read(self.env,self.var)

class Debug(Invertible):
    def __init__(self, env, var):
        self.env = env
        self.var = var

    def call(self):
        print(lookup(self.env,self.var))

    def invert(self):
        return Debug(self.env,self.var)

class Sequence(Invertible):
    def __init__(self,env,statements):
        self.env = env
        self.statements = statements

    def call(self):
        for s in self.statements:
            s.call()

    def invert(self):
        statementsCopy = self.statements.copy()
        statementsCopy.reverse()
        statementsCopy = [s.invert() for s in statementsCopy]
        return Sequence(self.env,statementsCopy)

class If(Invertible):
    def __init__(self,env,pred1,true_statement,false_statement,pred2):
        self.pred1 = pred1
        self.true_statement = true_statement
        self.false_statement = false_statement
        self.pred2 = pred2

    def call(self):
        bool1 = self.pred1.call()
        if bool1:
            self.true_statement.call()
        else:
            self.false_statement.call()

        bool2 = self.pred2.call()

        if bool1 != bool2:
            raise Exception ('Entry and exit predicate of if-statement did not agree')

    def invert(self):
        return If(env,self.pred2,self.true_statement.invert(),self.false_statement.invert(),self.pred1)


class While(Invertible):
    def __init__(self,env,pred,statement):
        self.env = env
        self.pred = pred
        self.statement = statement

    def call(self):
        while self.pred.call():
            print("Aldrig her?")
            self.statement.call()

    def invert(self):
        return While(self.env,self.pred,self.statement.invert())

class Until(Invertible):
    def __init__(self,env,pred,statement):
        self.env = env
        self.pred = pred
        self.statement = statement

    def call(self):
        while not(self.pred.call()):
            self.statement.call()

    def invert(self):
        return Until(self.env,self.pred,self.statement.invert())

class Local(Invertible):
    def __init__(self,env,var,statement):
        self.env = env
        self.var = var
        self.statement = statement

    def call(self):
        oldVal = lookup(self.env,self.var)
        self.env[self.var] = 0
        self.statement.call()
        if self.env[self.var] != 0:
            raise Exception ('Local variable ' + self.var + ' is not 0 at end of scope')
        self.env[self.var] = oldVal

    def invert(self):
        return Local(self.env, self.var, self.statement.invert())

class BaseExpr(Invertible):
    def __init__(self,env,val):
        self.env = env
        self.val = val

    def call(self):
        return assign(self.env,None)

    def assign(self,var):
        if var == self.val:
            raise Exception ('Variable ' + var + ' used in right-hand side while being assigned to')
        return lookup(self.env,self.val)

    def invert(self):
        return self


class Unop(Invertible):
    def __init__(self, env, unop, arg):
        self.env = env
        self.unop = unop
        self.arg = arg

    def call(self):
        return self.assign(None)

    def assign(self, var):
        if var == self.arg:
            raise Exception ('Variable ' + var + ' used in right-hand side while being assigned to')
        val = self.arg.assign(var)
        return self.unop(val)

    def invert(self):
        return self

class Binop(Invertible):
    def __init__(self, env, binop, arg1, arg2):
        self.env = env
        self.binop = binop
        self.arg1 = arg1
        self.arg2 = arg2

    def call(self):
        return self.assign(None)

    def assign(self,var):
        if var == self.arg1 or var == self.arg2:
            raise Exception ('Variable ' + var + ' used in right-hand side while being assigned to')
        val1 = self.arg1.assign(var)
        val2 = self.arg2.assign(var)
        return self.binop(val1,val2)

    def invert(self):
        return self

def id(env,arg):
    return Unop(env,(lambda x: x),arg)

def myNot(env,arg):
    return Unop(env,(lambda x: not(x)),arg)

#def myNot2(arg):

def plus(env,arg1,arg2):
    return Binop(env,(lambda x, y: x + y),arg1,arg2)

def eq(env,arg1,arg2):
    return Binop(env,(lambda x, y: x == y),arg1,arg2)

def myOr(env,arg1,arg2):
    return Binop(env,(lambda x, y: x or y),arg1,arg2)

def myAnd(env,arg1,arg2):
    return Binop(env,(lambda x, y: x and y),arg1,arg2)

def myMod(env,arg1,arg2):
    return Binop(env,myMod2,arg1,arg2)

def myMod2(x,y):
    return x % y

#pgh = PlusAssign(env,'gurd',5)

#ss = Sequence(env,[
#    PlusAssign(env,'gurd',5),
#    Swap(env,'hai','gurd')])

#i = If(env,False,ss,pgh,True)

fenv = {}

fac = Sequence(fenv,
               [Read(fenv,'m'),
               Read(fenv,'n'),
               Until(fenv,
                     myAnd(fenv,
                           eq(fenv,BaseExpr(fenv,'n'),BaseExpr(fenv,0)),
                           eq(fenv,BaseExpr(fenv,'g'),BaseExpr(fenv,0))),
                     Sequence(fenv,
                              [Write(fenv,'g'),
                               PlusAssign(fenv,'g',myMod(fenv,BaseExpr(fenv,'m'),BaseExpr(fenv,'n'))),
                               Swap(fenv,'m','n'),
                               Swap(fenv,'g','n')])),
                Write(fenv,'g'),
                Write(fenv,'m'),
                Write(fenv,'n')])


fum = {'n' : 0, 'g' : 0}
q = PlusAssign(fum,'t',
#               myNot(fum,
                     myOr(fum,
                          BaseExpr(fum,0),
                          BaseExpr(fum,1)))
def do():
    print(env)
    i.call()
    print(env)
    i.uncall()
    print(env)
