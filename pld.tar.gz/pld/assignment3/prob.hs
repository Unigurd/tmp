--{-# language NoMonomorphismRestriction #-}
-- hiding min because I want to mimic Troll's min
import Prelude hiding (round, min) 
import Data.List (sort, sortOn)

-- A list of events a with probability p
newtype Prob p a = Prob {prob :: [(a,p)]} deriving Show
--type DiceRoll = Prob Double Integer
-- indepent events
type IEvents = Prob Double [Integer]

-- prettyprinting
prettyProb :: (Show p, Show a) => Prob p a -> IO ()
prettyProb a = putStrLn $ unlines $ show <$> prob a

-- maps over the first element of a tuple
onFst f (a,b) = (f a, b)

-- allows function on the list inside the Prob, including the probabilites
onProb f = Prob . f . prob

-- return the singleton set of x
s = return . return

-- uniform distribution from a list
uniform :: [Integer] -> IEvents
uniform l = Prob $ map (\x -> ([x], 1/(fromIntegral $ length l))) l

-- n-side die
d n = uniform [1..n]

-- Like fmap for lists, but it doesn't access or change the probabilities.
instance Functor (Prob p) where
  fmap f (Prob l) = Prob $ fmap (\(x,p) -> (f x, p)) l

-- Like <*> for lists where 
-- the probability of each result element is 
-- the product of of the probability of the function
--  and the probability of the input
instance Fractional p => Applicative (Prob p) where
  pure a = Prob [(a,1)]
  af <*> xs = Prob [(f x,p1*p2) | (f,p1) <- prob af, (x,p2) <- prob xs]

-- Like the list monad instance, where the probabilities of each resulting event 
-- is multiplied by the probability of the input
instance Fractional p => Monad (Prob p) where
  return = pure
  m >>= f =  Prob [(y, p1*p2) | (x,p1) <- prob m, (y,p2) <- prob (f x)]

-- adding two independent events
instance (Fractional p, Monoid a) => Semigroup (Prob p a) where
  dice1 <> dice2 = do 
    roll1 <- dice1
    roll2 <- dice2
    return $ roll1 <> roll2

-- the empty event
instance (Fractional p, Monoid a) => Monoid (Prob p a) where
  mempty = return mempty

-- combines similar events, adding their probabilities
combine :: IEvents -> IEvents
combine = onProb $ combineRec . sortOn fst . map (onFst sort)
  where
    combineOne p [] = [p]
    combineOne new@(elm1,p1) list@((elm2,p2):rest) =
      if elm1 == elm2 then (elm1, p1+p2):rest
      else new:list
    combineRec = foldr combineOne []

-- adds dice to the previous collection of events, applies f to them, and combines the result.
-- f is a function that determines what happens.
-- f can be used to only keep the largest/smallest dice rolls,
-- just let the set of dice grow unfiltered, or what have you.
round ::  ([Integer] -> [Integer]) -> IEvents -> IEvents -> IEvents
round f dice prevs = combine $ f <$> dice <> prevs

-- applies round repeatedly, resulting in an infinite list of 
-- applications of round to beginning element accDice
limitedRolls :: ([Integer] -> [Integer]) -> IEvents -> IEvents -> [IEvents]
limitedRolls f dice accDice = iterate (round f dice) accDice

-- drops the smallest dice roll from a list
keepLargest :: Ord a => [a] -> [a]
keepLargest = drop 1 . sort

-- infinite list of Ievents with increasingly more dice
-- id means we don't filter the results in round
rolls dice = limitedRolls id dice dice

-- Generates an infinite list, where the Ievents grows freely for the first maxDice events,
-- and then afterwards grows accordingly to f
rounds :: ([Integer] -> [Integer]) -> Int -> IEvents -> [IEvents]
rounds f maxDice dice = firstDice ++ (limitedRolls f dice $ last firstDice)
 where
   firstDice = take maxDice $ rolls dice

-- keeps the largest n dice from repeated dice rolls
largest n dice = rounds (drop 1 . sort) n dice

-- Takes the smallest dice
min :: IEvents -> IEvents
min = fmap (take 1 . sort)

-- Returns a new Ievents where the probability of each element 
-- is the product of it's probabilities in dice1 and dice2
(===) :: IEvents -> IEvents -> IEvents
dice1 === dice2 = combine $ do 
  roll1 <- dice1
  roll2 <- dice2
  return $ if roll1 == roll2 then roll1 else []
  
-- Calculate the probability of the 3rd largest of 39 d9 is 8
result = s 8 === (min ((largest 3 (d 9)) !! 39))

---- 8 = min (largest 3 39d9)
