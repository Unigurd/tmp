machine(x86).
machine(arm).
compiler(c,arm,arm).
compiler(haskell,c,haskell).
interpreter(ml,x86).
interpreter(haskell,c).
program(ml).
program(haskell).

%machine(x86).
%machine(arm).
%compiler(c,arm,arm).
%%compiler(haskell,c,haskell).
%compiler(c,c,arm).
%interpreter(ml,x86).
%interpreter(haskell,c).
%%interpreter(haskell,haskell).
%program(ml).
%program(haskell).

writtenIn(M,T) :- compiler(From,To,M), T = compiler(From,To,M).
writtenIn(M,T) :- interpreter(I,M), T = interpreter(I,M).
writtenIn(M,T) :- program(M), T = program(M).

canRun(L) :- machine(L).
canRun(L1) :-
    interpreter(L1,L2),
    L1 \= L2,
    canRun(L2).
canRun(L1) :-
    compiler(L1,L2,L3),
    L1 \= L3,
    L1 \= L2,
    canRun(L2),
    canRun(L3).
